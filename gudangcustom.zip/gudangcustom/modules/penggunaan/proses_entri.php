<?php
session_start(); // Mengaktifkan session

// Pengecekan session login user
if (empty($_SESSION['username']) && empty($_SESSION['password'])) {
  // Alihkan ke halaman login dan tampilkan pesan peringatan login
  header('location: ../../login.php?pesan=2');
} else {
  // Panggil file "database.php" untuk koneksi ke database
  require_once "../../config/database.php";

  // Mengecek data hasil submit dari form
  if (isset($_POST['simpan'])) {
    // Ambil data hasil submit dari form
    $id_penggunaan  = mysqli_real_escape_string($mysqli, $_POST['id_penggunaan']);
    $pekerja_id     = mysqli_real_escape_string($mysqli, trim($_POST['pekerja_id']));
    $peralatan_id   = mysqli_real_escape_string($mysqli, trim($_POST['peralatan_id']));
    $tanggal_gunakan  = mysqli_real_escape_string($mysqli, trim($_POST['tanggal_gunakan']));
    $tanggal_kembali  = mysqli_real_escape_string($mysqli, trim($_POST['tanggal_kembali']));
    $status_barang  = mysqli_real_escape_string($mysqli, trim($_POST['status_barang']));
    $keterangan     = mysqli_real_escape_string($mysqli, $_POST['keterangan']);

    // SQL statement untuk insert data ke tabel "tbl_peralatan"
    $insert = mysqli_query($mysqli, "INSERT INTO tbl_penggunaan(id_penggunaan, pekerja_id, peralatan_id, tanggal_gunakan, tanggal_kembali, status_barang, keterangan) 
                                     VALUES('$id_penggunaan', '$pekerja_id','$peralatan_id', '$tanggal_gunakan','$tanggal_kembali','$status_barang','$keterangan')")
                                     or die('Ada kesalahan pada query insert : ' . mysqli_error($mysqli));

    // Cek query
    if ($insert) {
      // Alihkan ke halaman penggunaan dan tampilkan pesan berhasil simpan data
      header('location: ../../main.php?module=penggunaan&pesan=1');
    }
  }
}
?>
