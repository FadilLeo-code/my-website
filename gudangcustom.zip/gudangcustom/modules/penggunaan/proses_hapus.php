<?php
session_start(); // Mengaktifkan session

// Pengecekan session login user
if (empty($_SESSION['username']) && empty($_SESSION['password'])) {
  // Alihkan ke halaman login dan tampilkan pesan peringatan login
  header('location: ../../login.php?pesan=2');
} else {
  // Panggil file "database.php" untuk koneksi ke database
  require_once "../../config/database.php";

  // Mengecek data GET "id_penggunaan"
  if (isset($_GET['id'])) {
    // Ambil data GET dari tombol hapus
    $id_penggunaan = mysqli_real_escape_string($mysqli, $_GET['id']);

    // SQL statement untuk delete data dari tabel "tbl_penggunaan" berdasarkan "id_penggunaan"
    $delete = mysqli_query($mysqli, "DELETE FROM tbl_penggunaan WHERE id_penggunaan='$id_penggunaan'")
      or die('Ada kesalahan pada query delete : ' . mysqli_error($mysqli));

    // Cek query
    if ($delete) {
      // Alihkan ke halaman penggunaan dan tampilkan pesan berhasil hapus data
      header('location: ../../main.php?module=penggunaan&pesan=3');
    }
  }
}
?>
