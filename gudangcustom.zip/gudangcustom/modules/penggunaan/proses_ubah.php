<?php
session_start(); // Mengaktifkan session

// Pengecekan session login user
if (empty($_SESSION['username']) && empty($_SESSION['password'])) {
  // Alihkan ke halaman login dan tampilkan pesan peringatan login
  header('location: ../../login.php?pesan=2');
} else {
  // Panggil file "database.php" untuk koneksi ke database
  require_once "../../config/database.php";

  // Mengecek data hasil submit dari form
  if (isset($_POST['simpan'])) {
    // Ambil data hasil submit dari form
    $id_penggunaan   = mysqli_real_escape_string($mysqli, $_POST['id_peralatan']);
    $pekerja_id      = mysqli_real_escape_string($mysqli, trim($_POST['pekerja_id']));
    $peralatan_id    = mysqli_real_escape_string($mysqli, trim($_POST['peralatan_id']));
    $tanggal_gunakan = mysqli_real_escape_string($mysqli, trim($_POST['tanggal_gunakan']));
    $tanggal_kembali = mysqli_real_escape_string($mysqli, trim($_POST['tanggal_kembali']));
    $status_barang   = mysqli_real_escape_string($mysqli, $_POST['status_barang']);
    $keterangan      = mysqli_real_escape_string($mysqli, $_POST['keterangan']);

    // SQL statement untuk update data di tabel "tbl_peralatan"
    $update = mysqli_query($mysqli, "UPDATE tbl_penggunaan
                                     SET pekerja_id='$pekerja_id',
                                         peralatan_id='$peralatan_id',
                                         tanggal_gunakan='$tanggal_gunakan',
                                         tanggal_kembali='$tanggal_kembali',
                                         status_barang='$status_barang',
                                         keterangan='$keterangan'
                                     WHERE id_penggunaan='$id_penggunaan'")
                                     or die('Ada kesalahan pada query update : ' . mysqli_error($mysqli));

    // Cek query
    if ($update) {
      // Alihkan ke halaman penggunaan dan tampilkan pesan berhasil ubah data
      header('location: ../../main.php?module=penggunaan&pesan=2');
    }
  }
}
?>
