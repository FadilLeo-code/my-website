<?php
// mencegah direct access file PHP agar file PHP tidak bisa diakses secara langsung dari browser dan hanya dapat dijalankan ketika di include oleh file lain
// jika file diakses secara langsung
if (basename($_SERVER['PHP_SELF']) === basename(__FILE__)) {
  // alihkan ke halaman error 404
  header('location: 404.html');
}
// jika file di include oleh file lain, tampilkan isi file
else {
  // mengecek data GET "id_penggunaan"
  if (isset($_GET['id'])) {
    // ambil data GET dari tombol detail
    $id_penggunaan = $_GET['id'];

    // sql statement untuk menampilkan data dari tabel "tbl_penggunaan", tabel "tbl_jenis", dan tabel "tbl_satuan" berdasarkan "id_penggunaan"
    $query = mysqli_query($mysqli, "SELECT a.id_penggunaan, a.pekerja_id, a.peralatan_id, a.tanggal_gunakan, a.tanggal_kembali, a.status_barang, a.keterangan, b.nama, c.nama_peralatan FROM tbl_penggunaan AS a INNER JOIN tbl_pekerja AS b INNER JOIN tbl_peralatan AS c ON a.pekerja_id=b.id_pekerja AND a.peralatan_id=c.id_peralatan WHERE id_penggunaan='$id_penggunaan'")
      or die('Ada kesalahan pada query tampil data: ' . mysqli_error($mysqli));
    // ambil data hasil query
    $data = mysqli_fetch_assoc($query);
  }
?>
  <div class="panel-header" style="background: linear-gradient(to bottom, #800000, #b22222);">
    <div class="page-inner py-45">
      <div class="d-flex align-items-left align-items-md-top flex-column flex-md-row">
        <div class="page-header text-white">
          <!-- judul halaman -->
          <h4 class="page-title text-white"><i class="fas fa-clone mr-2"></i> Penggunaan Peralatan</h4>
          <!-- breadcrumbs -->
          <ul class="breadcrumbs">
            <li class="nav-home"><a href="?module=dashboard"><i class="flaticon-home text-white"></i></a></li>
            <li class="separator"><i class="flaticon-right-arrow"></i></li>
            <li class="nav-item"><a href="?module=penggunaan" class="text-white">Penggunaan Peralatan</a></li>
            <li class="separator"><i class="flaticon-right-arrow"></i></li>
            <li class="nav-item"><a>Detail</a></li>
          </ul>
        </div>
        <div class="ml-md-auto py-2 py-md-0">
          <!-- tombol kembali ke halaman data penggunaan -->
          <a href="?module=penggunaan" class="btn btn-secondary btn-round">
            <span class="btn-label"><i class="far fa-arrow-alt-circle-left mr-2"></i></span> Kembali
          </a>
        </div>
      </div>
    </div>
  </div>

  <div class="page-inner mt--5">
    <div class="row">
      <div class="col-md-8">
        <div class="card">
          <div class="card-header">
            <!-- judul form -->
            <div class="card-title">Detail Data Penggunaan Peralatan</div>
          </div>
          <!-- detail data -->
          <div class="card-body">
            <table class="table table-striped">
              <tr>
                <td>Nama Pekerja</td>
                <td>:</td>
                <td><?php echo $data['nama']; ?></td>
              </tr>
              <tr>
                <td>Nama Barang</td>
                <td>:</td>
                <td><?php echo $data['nama_peralatan']; ?></td>
              </tr>
              <tr>
                <td>Tanggal Menggunakan</td>
                <td>:</td>
                <td><?php echo date('d-m-Y', strtotime($data['tanggal_gunakan'])); ?></td>
              </tr>
              <tr>
                <td>Tanggal Menggunakan</td>
                <td>:</td>
                <td><?php echo date('d-m-Y', strtotime($data['tanggal_kembali'])); ?></td>
              </tr>
              <tr>
                <td>Status Barang</td>
                <td>:</td>
                <td>
                  <span class="badge <?php echo ($data['status_barang'] == 'Baik') ? 'bg-success' : 'bg-danger'; ?>">
                    <?php echo $data['status_barang']; ?>
                  </span>
                </td>
              </tr>

              <tr>
                <td>Keterangan</td>
                <td>:</td>
                <td><?php echo $data['keterangan']; ?></td>
              </tr>
            </table>
          </div>
        </div>
      </div>

    </div>
  </div>
<?php } ?>