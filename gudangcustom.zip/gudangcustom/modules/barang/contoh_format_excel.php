<?php
require '/vendor/autoload.php'; // Pastikan path ke autoload benar

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

// Buat Spreadsheet baru
$spreadsheet = new Spreadsheet();
$sheet = $spreadsheet->getActiveSheet();

// Header Kolom
$headers = ['id_barang', 'nama_barang', 'jenis', 'stok_minimum', 'stok', 'satuan', 'lokasi_ruangan', 'lokasi_rak', 'keterangan'];
foreach ($headers as $key => $header) {
    $sheet->setCellValueByColumnAndRow($key + 1, 1, $header);
}

// Contoh data (baris kedua)
$exampleData = [
    'BR001', 'Barang Contoh', 1, 10, 100.5, 2, 'Gudang A', 'Rak 1A', 'Contoh keterangan'
];
foreach ($exampleData as $key => $value) {
    $sheet->setCellValueByColumnAndRow($key + 1, 2, $value);
}

// Buat file Excel
$filename = 'Contoh_Format_Import_Barang.xlsx';
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment; filename="' . $filename . '"');

$writer = new Xlsx($spreadsheet);
$writer->save('php://output');
exit;
?>
