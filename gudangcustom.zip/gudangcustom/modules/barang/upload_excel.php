<?php
require 'vendor/autoload.php'; // Pastikan path ke autoload benar

use PhpOffice\PhpSpreadsheet\IOFactory;

// Koneksi ke database
$conn = new mysqli('localhost', 'root', '', 'gudangcustom');
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Cek apakah file diupload
if (isset($_FILES['file']['tmp_name'])) {
    $filePath = $_FILES['file']['tmp_name'];

    try {
        $spreadsheet = IOFactory::load($filePath);
        $sheet = $spreadsheet->getActiveSheet();
        $data = $sheet->toArray();

        // Loop untuk memproses data
        foreach ($data as $index => $row) {
            if ($index == 0) continue; // Skip header row

            // Pastikan urutan kolom sesuai
            $id_barang = $row[0];
            $nama_barang = $row[1];
            $jenis = $row[2];
            $stok_minimum = $row[3];
            $stok = $row[4];
            $satuan = $row[5];
            $lokasi_ruangan = $row[6];
            $lokasi_rak = $row[7];
            $keterangan = $row[8];

            // Insert ke database
            $sql = "INSERT INTO tbl_barang (id_barang, nama_barang, jenis, stok_minimum, stok, satuan, lokasi_ruangan, lokasi_rak, keterangan)
                    VALUES ('$id_barang', '$nama_barang', $jenis, $stok_minimum, $stok, $satuan, '$lokasi_ruangan', '$lokasi_rak', '$keterangan')";
            $conn->query($sql);
        }

        echo "Data berhasil diimport!";
    } catch (Exception $e) {
        echo "Error: " . $e->getMessage();
    }
} else {
    echo "Harap upload file Excel.";
}
?>
