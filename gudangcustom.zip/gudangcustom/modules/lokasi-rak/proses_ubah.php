<?php
session_start();      // mengaktifkan session

// pengecekan session login user 
// jika user belum login
if (empty($_SESSION['username']) && empty($_SESSION['password'])) {
  // alihkan ke halaman login dan tampilkan pesan peringatan login
  header('location: ../../login.php?pesan=2');
}
// jika user sudah login, maka jalankan perintah untuk update
else {
  // panggil file "database.php" untuk koneksi ke database
  require_once "../../config/database.php";

  // mengecek data hasil submit dari form
  if (isset($_POST['simpan'])) {
    // ambil data hasil submit dari form
    $id_lokasi   = mysqli_real_escape_string($mysqli, $_POST['id_lokasi']);
    $lokasi_rak = mysqli_real_escape_string($mysqli, trim($_POST['lokasi_rak']));

    // mengecek "lokasi_ruangan" untuk mencegah data duplikat
    // sql statement untuk menampilkan data "lokasi_ruangan" dari tabel "tbl_lokasi" berdasarkan input "lokasi_ruangan"
    $query = mysqli_query($mysqli, "SELECT lokasi_rak FROM tbl_lokasi_rak WHERE lokasi_rak ='$lokasi_rak' AND id_lokasi!='$id_lokasi'")
                                    or die('Ada kesalahan pada query tampil data : ' . mysqli_error($mysqli));
    // ambil jumlah baris data hasil query
    $rows = mysqli_num_rows($query);

    // cek hasil query
    // jika "lokasi_ruangan" sudah ada di tabel "tbl_lokasi"
    if ($rows <> 0) {
      // alihkan ke halaman lokasi dan tampilkan pesan gagal ubah data
      header("location: ../../main.php?module=lokasi-rak&pesan=4&lokasi-rak=$lokasi_rak");
    }
    // jika "lokasi_ruangan" belum ada di tabel "tb_lokasi"
    else {
      // sql statement untuk update data di tabel "tbl_lokasi" berdasarkan "id_lokasi"
      $update = mysqli_query($mysqli, "UPDATE tbl_lokasi_rak
                                       SET lokasi_rak='$lokasi_rak'
                                       WHERE id_lokasi='$id_lokasi'")
                                       or die('Ada kesalahan pada query update : ' . mysqli_error($mysqli));
      // cek query
      // jika proses update berhasil
      if ($update) {
        // alihkan ke halaman lokasi dan tampilkan pesan berhasil ubah data
        header('location: ../../main.php?module=lokasi-rak&pesan=2');
      }
    }
  }
}
