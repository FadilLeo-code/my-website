<?php
// mencegah direct access file PHP agar file PHP tidak bisa diakses secara langsung dari browser dan hanya dapat dijalankan ketika di include oleh file lain
// jika file diakses secara langsung
if (basename($_SERVER['PHP_SELF']) === basename(__FILE__)) {
  // alihkan ke halaman error 404
  header('location: 404.html');
}
// jika file di include oleh file lain, tampilkan isi file
else {
  // mengecek data GET "id_pekerja"
  if (isset($_GET['id'])) {
    // ambil data GET dari tombol detail
    $id_pekerja = $_GET['id'];

    // sql statement untuk menampilkan data dari tabel "tbl_pekerja", tabel "tbl_jenis", dan tabel "tbl_satuan" berdasarkan "id_pekerja"
    $query = mysqli_query($mysqli, "SELECT id_pekerja,nama, no_wa, foto
    FROM tbl_pekerja 
    ORDER BY id_pekerja DESC")
      or die('Ada kesalahan pada query tampil data : ' . mysqli_error($mysqli));
    // ambil data hasil query
    $data = mysqli_fetch_assoc($query);
  }
?>
  <div class="panel-header" style="background: linear-gradient(to bottom, #800000, #b22222);">
    <div class="page-inner py-45">
      <div class="d-flex align-items-left align-items-md-top flex-column flex-md-row">
        <div class="page-header text-white">
          <!-- judul halaman -->
          <h4 class="page-title text-white"><i class="fas fa-clone mr-2"></i> Pekerja</h4>
          <!-- breadcrumbs -->
          <ul class="breadcrumbs">
            <li class="nav-home"><a href="?module=dashboard"><i class="flaticon-home text-white"></i></a></li>
            <li class="separator"><i class="flaticon-right-arrow"></i></li>
            <li class="nav-item"><a href="?module=pekerja" class="text-white">Pekerja</a></li>
            <li class="separator"><i class="flaticon-right-arrow"></i></li>
            <li class="nav-item"><a>Detail</a></li>
          </ul>
        </div>
        <div class="ml-md-auto py-2 py-md-0">
          <!-- tombol kembali ke halaman data pekerja -->
          <a href="?module=pekerja" class="btn btn-secondary btn-round">
            <span class="btn-label"><i class="far fa-arrow-alt-circle-left mr-2"></i></span> Kembali
          </a>
        </div>
      </div>
    </div>
  </div>

  <div class="page-inner mt--5">
    <div class="row">
      <div class="col-md-8">
        <div class="card">
          <div class="card-header">
            <!-- judul form -->
            <div class="card-title">Detail Data Pekerja</div>
          </div>
          <!-- detail data -->
          <div class="card-body">
            <table class="table table-striped">
              <tr>
                <td>Nama pekerja</td>
                <td>:</td>
                <td><?php echo $data['nama']; ?></td>
              </tr>
              <tr>
                <td>Nomor WA</td>
                <td>:</td>
                <td><?php echo $data['no_wa']; ?></td>
              </tr>
            </table>
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="card">
          <div class="card-body text-center">
            <?php
            // mengecek data foto barang
            // jika data "foto" tidak ada di database
            if (is_null($data['foto'])) { ?>
              <!-- tampilkan foto default -->
              <img style="max-height:375px" src="images/no_image.png" class="img-fluid" alt="Foto Barang">
            <?php
            }
            // jika data "foto" ada di database
            else { ?>
              <!-- tampilkan foto barang dari database -->
              <img style="max-height:375px" src="images/<?php echo $data['foto']; ?>" class="img-fluid" alt="Foto Barang">
            <?php } ?>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php } ?>