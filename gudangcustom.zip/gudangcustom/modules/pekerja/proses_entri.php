<?php
session_start();      // mengaktifkan session

// pengecekan session login user 
// jika user belum login
if (empty($_SESSION['username']) && empty($_SESSION['password'])) {
  // alihkan ke halaman login dan tampilkan pesan peringatan login
  header('location: ../../login.php?pesan=2');
}
// jika user sudah login, maka jalankan perintah untuk insert
else {
  // panggil file "database.php" untuk koneksi ke database
  require_once "../../config/database.php";

  // mengecek data hasil submit dari form
  if (isset($_POST['simpan'])) {
    // ambil data hasil submit dari form
    $id_pekerja          = mysqli_real_escape_string($mysqli, $_POST['id_pekerja']);
    $nama        = mysqli_real_escape_string($mysqli, trim($_POST['nama']));
    $no_wa             = mysqli_real_escape_string($mysqli, $_POST['no_wa']);

    // ambil data file hasil submit dari form
    $nama_file          = $_FILES['foto']['name'];
    $tmp_file           = $_FILES['foto']['tmp_name'];
    $extension          = array_pop(explode(".", $nama_file));
    // enkripsi nama file
    $nama_file_enkripsi = sha1(md5(time() . $nama_file)) . '.' . $extension;
    // tentukan direktori penyimpanan file foto
    $path               = "../../images/" . $nama_file_enkripsi;

    // mengecek data foto dari form entri data
    // jika data foto tidak ada
    if (empty($nama_file)) {
      // sql statement untuk insert data ke tabel "tbl_pekerja"
      $insert = mysqli_query($mysqli, "INSERT INTO tbl_pekerja(id_pekerja, nama, no_wa) 
                                       VALUES('$id_pekerja', '$nama', '$no_wa')")
                                       or die('Ada kesalahan pada query insert : ' . mysqli_error($mysqli));
      // cek query
      // jika proses insert berhasil
      if ($insert) {
        // alihkan ke halaman pekerja dan tampilkan pesan berhasil simpan data
        header('location: ../../main.php?module=pekerja&pesan=1');
      }
    }
    // jika data foto ada
    else {
      // lakukan proses unggah file
      // jika file berhasil diunggah
      if (move_uploaded_file($tmp_file, $path)) {
        // sql statement untuk insert data ke tabel "tbl_pekerja"
        $insert = mysqli_query($mysqli, "INSERT INTO tbl_pekerja(id_pekerja, nama, no_wa, foto) 
                                         VALUES('$id_pekerja', '$nama', '$no_wa', '$nama_file_enkripsi')")
                                         or die('Ada kesalahan pada query insert : ' . mysqli_error($mysqli));
        // cek query
        // jika proses insert berhasil
        if ($insert) {
          // alihkan ke halaman pekerja dan tampilkan pesan berhasil simpan data
          header('location: ../../main.php?module=pekerja&pesan=1');
        }
      }
    }
    // jika data foto ada
    
  }
}
