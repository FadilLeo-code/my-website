<?php
session_start();      // mengaktifkan session

// include autoloader untuk load dompdf, libraries, dan helper functions
require_once("../../assets/js/plugin/dompdf/autoload.inc.php");
// mereferensikan Dompdf namespace
use Dompdf\Dompdf;

// pengecekan session login user 
// jika user belum login
if (empty($_SESSION['username']) && empty($_SESSION['password'])) {
  // alihkan ke halaman login dan tampilkan pesan peringatan login
  header('location: ../../login.php?pesan=2');
}
// jika user sudah login, maka jalankan perintah untuk cetak
else {
  // panggil file "database.php" untuk koneksi ke database
  require_once "../../config/database.php";
  // panggil file "fungsi_tanggal_indo.php" untuk membuat format tanggal indonesia
  require_once "../../helper/fungsi_tanggal_indo.php";

  // ambil data GET dari tombol cetak
  $tanggal_awal  = $_GET['tanggal_awal'];
  $tanggal_akhir = $_GET['tanggal_akhir'];

  // gunakan dompdf class
  $dompdf = new Dompdf();
  // setting options
  $options = $dompdf->getOptions();
  $options->setIsRemoteEnabled(true); // aktifkan akses file untuk bisa mengakses file gambar dan CSS
  $options->setChroot('C:\xampp\htdocs\gudang'); // tentukan path direktori aplikasi
  $dompdf->setOptions($options);

  // halaman HTML yang akan diubah ke PDF
  $html = '<!DOCTYPE html>
          <html>
          <head>
              <title>Laporan Data Barang Keluar</title>
            <link href="../../assets/css/laporan.css" rel="stylesheet">
            <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f9f9f9;
            color: #333;
        }
        .header {
            text-align: center;
            margin-bottom: 20px;
        }
        .header h2 {
            font-size: 24px;
            text-transform: uppercase;
            margin: 0;
            color: #444;
        }
        .header span {
            font-size: 14px;
            color: #777;
        }
        hr {
            border: 0;
            height: 2px;
            background: #333;
            margin-bottom: 20px;
        }
        .table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        .table th, .table td {
            padding: 10px;
            text-align: center;
            border: 1px solid #ddd;
        }
        .table th {
            background-color: #28a745;
            color: white;
            text-transform: uppercase;
        }
        .table tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        .table tr:hover {
            background-color: #ddd;
        }
        .table td {
            font-size: 14px;
        }
        .text-right {
            text-align: right;
            font-size: 14px;
            color: #555;
            margin-top: 30px;
        }
        .text-right .date {
            font-weight: bold;
        }
    </style>
          </head>
          <body class="text-dark">
            <div class="header">
              <h2>LAPORAN DATA BARANG KELUAR</h2>
              <span>Tanggal ' . $tanggal_awal . ' s.d. ' . $tanggal_akhir . '</span>
            </div>
            <hr>
            <div class="mt-4">
              <table class="table">
        <thead>
            <tr>
                <th>No.</th>
                <th>ID Transaksi</th>
                <th>Tanggal</th>
                <th>Barang</th>
                <th>Jumlah Keluar</th>
                <th>Satuan</th>
                <th>Lokasi Ruangan</th>
                <th>Lokasi Rak</th>
                <th>Operator</th>
            </tr>
		            </thead>
						    <tbody class="text-dark">';
  // ubah format tanggal menjadi Tahun-Bulan-Hari (Y-m-d)
  $tanggal_awal  = date('Y-m-d', strtotime($tanggal_awal));
  $tanggal_akhir = date('Y-m-d', strtotime($tanggal_akhir));
  // variabel untuk nomor urut tabel 
  $no = 1;
  // sql statement untuk menampilkan data dari tabel "tbl_barang_keluar", tabel "tbl_barang", dan tabel "tbl_satuan" berdasarkan "tanggal"
  $query = mysqli_query($mysqli, "SELECT a.id_transaksi, a.tanggal, a.barang, a.jumlah, a.nama_operator, a.lokasi_ruangan, a.lokasi_rak, b.nama_barang, c.nama_satuan, d.nama_operator, e.lokasi_ruangan, f.lokasi_rak
                FROM tbl_barang_keluar as a INNER JOIN tbl_barang as b INNER JOIN tbl_satuan as c INNER JOIN tbl_operator as d INNER JOIN tbl_lokasi as e INNER JOIN tbl_lokasi_rak as f
                ON a.barang=b.id_barang AND b.satuan=c.id_satuan AND a.nama_operator=d.id_operator AND a.lokasi_ruangan=e.id_lokasi AND a.lokasi_rak=f.id_lokasi
                ORDER BY a.id_transaksi DESC")
                or die('Ada kesalahan pada query tampil data : ' . mysqli_error($mysqli));
  // ambil data hasil query
  $no = 1;
while ($data = mysqli_fetch_assoc($query)) {
    $html .= '  <tr>
                    <td>' . $no++ . '</td>
                    <td>' . $data['id_transaksi'] . '</td>
                    <td>' . date('d-m-Y', strtotime($data['tanggal'])) . '</td>
                    <td>' . $data['barang'] . ' - ' . $data['nama_barang'] . '</td>
                    <td>' . number_format($data['jumlah'], 0, '', '.') . '</td>
                    <td>' . $data['nama_satuan'] . '</td>
                    <td>' . $data['lokasi_ruangan'] . '</td>
                    <td>' . $data['lokasi_rak'] . '</td>
                    <td>' . $data['nama_operator'] . '</td>
                </tr>';
}

  $html .= '		</tbody>
              </table>
            </div>
            <div class="text-right mt-5">............, ' . tanggal_indo(date('Y-m-d')) . '</div>
            </body>
          </html>';

  // load html
  $dompdf->loadHtml($html);
  // mengatur ukuran dan orientasi kertas
  $dompdf->setPaper('A4', 'landscape');
  // mengubah dari HTML menjadi PDF
  $dompdf->render();
  // menampilkan file PDF yang dihasilkan ke browser dan berikan nama file "Laporan Data Barang Keluar.pdf"
  $dompdf->stream('Laporan Data Barang Keluar.pdf', array('Attachment' => 0));
}
