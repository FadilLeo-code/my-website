<?php
session_start();      // mengaktifkan session

// panggil file "autoload.inc.php" untuk load dompdf, libraries, dan helper functions
require_once("../../assets/js/plugin/dompdf/autoload.inc.php");
// mereferensikan Dompdf namespace
use Dompdf\Dompdf;

// pengecekan session login user 
// jika user belum login
if (empty($_SESSION['username']) && empty($_SESSION['password'])) {
  // alihkan ke halaman login dan tampilkan pesan peringatan login
  header('location: ../../login.php?pesan=2');
}
// jika user sudah login, maka jalankan perintah untuk cetak
else {
  // panggil file "database.php" untuk koneksi ke database
  require_once "../../config/database.php";
  // panggil file "fungsi_tanggal_indo.php" untuk membuat format tanggal indonesia
  require_once "../../helper/fungsi_tanggal_indo.php";

  // ambil data GET dari tombol cetak
  $stok = $_GET['stok'];

  // variabel untuk nomor urut tabel 
  $no = 1;

  // gunakan dompdf class
  $dompdf = new Dompdf();
  // setting options
  $options = $dompdf->getOptions();
  $options->setIsRemoteEnabled(true); // aktifkan akses file untuk bisa mengakses file gambar dan CSS
  $options->setChroot('C:\xampp\htdocs\gudang'); // tentukan path direktori aplikasi
  $dompdf->setOptions($options);

  // mengecek filter data stok
  // jika filter data stok "Seluruh" dipilih, tampilkan laporan stok seluruh barang
  if ($stok == 'Seluruh') {
    // halaman HTML yang akan diubah ke PDF
    $html = '<!DOCTYPE html>
            <html>
            <head>
    <title>Laporan Stok Seluruh Barang</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        .header {
            text-align: center;
            margin-bottom: 20px;
        }
        .header h1 {
            margin: 0;
            font-size: 24px;
            color: #333;
        }
        .header p {
            margin: 5px 0 0;
            font-size: 14px;
            color: #666;
        }
        hr {
            border: 0;
            height: 1px;
            background: #ddd;
            margin: 20px 0;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }
        table th, table td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: center;
        }
        table th {
            background-color: #f4f4f4;
            color: #333;
            font-weight: bold;
        }
        table tbody tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        table tbody tr:nth-child(odd) {
            background-color: #ffffff;
        }
        .badge-warning {
            background-color: #ffcc00;
            color: #333;
            padding: 5px 10px;
            border-radius: 5px;
        }
        .footer {
            text-align: right;
            font-size: 12px;
            color: #666;
            margin-top: 20px;
        }
        .signature {
            margin-top: 50px;
            display: flex;
            justify-content: space-between;
        }
        .signature .sign-box {
            width: 30%;
            text-align: center;
        }
        .signature .sign-box p {
            margin: 70px 0 10px;
            border-top: 1px solid #000;
            padding-top: 5px;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>LAPORAN STOK SELURUH BARANG</h1>
        <p>Gudang XYZ | ' . tanggal_indo(date('Y-m-d')) . '</p>
    </div>
    <hr>
    <table>
        <thead>
            <tr>
                <th>No.</th>
                <th>ID Barang</th>
                <th>Nama Barang</th>
                <th>Jenis Barang</th>
                <th>Stok</th>
                <th>Satuan</th>
                <th>Lokasi Ruangan</th>
                <th>Lokasi Rak</th>
            </tr>
        </thead>
        <tbody>';
    // sql statement untuk menampilkan data dari tabel "tbl_barang", tabel "tbl_jenis", dan tabel "tbl_satuan"
    $query = mysqli_query($mysqli, "SELECT a.id_barang, a.nama_barang, a.jenis, a.stok_minimum, a.stok, a.satuan, a.lokasi_ruangan, a.lokasi_rak, b.nama_jenis, c.nama_satuan, d.lokasi_ruangan, e.lokasi_rak
                                                  FROM tbl_barang as a INNER JOIN tbl_jenis as b INNER JOIN tbl_satuan as c INNER JOIN tbl_lokasi as d INNER JOIN tbl_lokasi_rak as e
                                                  ON a.jenis=b.id_jenis AND a.satuan=c.id_satuan  AND a.lokasi_ruangan=d.id_lokasi AND a.lokasi_rak=e.id_lokasi
                                                  ORDER BY a.id_barang ASC")
                                                  or die('Ada kesalahan pada query tampil data : ' . mysqli_error($mysqli));
    // ambil data hasil query
    while ($data = mysqli_fetch_assoc($query)) {
      $html .= '<tr>
          <td>' . $no++ . '</td>
          <td>' . $data['id_barang'] . '</td>
          <td>' . $data['nama_barang'] . '</td>
          <td>' . $data['nama_jenis'] . '</td>';
      if ($data['stok'] <= $data['stok_minimum']) {
          $html .= '<td><span class="badge-warning">' . $data['stok'] . '</span></td>';
      } else {
          $html .= '<td>' . $data['stok'] . '</td>';
      }
      $html .= '<td>' . $data['nama_satuan'] . '</td>
                <td>' . $data['lokasi_ruangan'] . '</td>
                <td>' . $data['lokasi_rak'] . '</td>
            </tr>';
  }
  $html .= '    </tbody>
    </table>
    <div class="footer">
        Dicetak pada: ' . tanggal_indo(date('Y-m-d')) . '
        <div class="signature">
        <div class="sign-box">
            <p>.........................</p>
        </div>
        </div>
    </div>
    </div>
</body>
</html>';

    // load html
    $dompdf->loadHtml($html);
    // mengatur ukuran dan orientasi kertas
    $dompdf->setPaper('A4', 'landscape');
    // mengubah dari HTML menjadi PDF
    $dompdf->render();
    // menampilkan file PDF yang dihasilkan ke browser dan berikan nama file "Laporan Stok Seluruh Barang.pdf"
    $dompdf->stream('Laporan Stok Seluruh Barang.pdf', array('Attachment' => 0));
  }
  // jika filter data stok "Minimum" dipilih, tampilkan laporan stok barang yang mencapai batas minimum
  else {
    // halaman HTML yang akan diubah ke PDF
    $html = '<!DOCTYPE html>
            <html>
            <head>
              <title>Laporan Stok Barang Minimum</title>
              <link rel="stylesheet" href="../../assets/css/laporan.css">
              <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f9f9f9;
            color: #333;
        }
        h1 {
            font-size: 24px;
            text-align: center;
            color: #444;
            margin-bottom: 10px;
            text-transform: uppercase;
        }
        hr {
            border: 0;
            height: 2px;
            background: #333;
            margin-bottom: 20px;
        }
        .table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        .table th, .table td {
            padding: 10px;
            text-align: center;
            border: 1px solid #ddd;
        }
        .table th {
            background-color: #4CAF50;
            color: white;
            text-transform: uppercase;
        }
        .table tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        .table tr:hover {
            background-color: #ddd;
        }
        .footer {
            text-align: right;
            margin-top: 30px;
            font-size: 14px;
            color: #555;
        }
        .footer .date {
            font-weight: bold;
        }
    </style>
            </head>
            <body class="text-dark">
              <div class="text-center mb-4">
                <h1>LAPORAN STOK BARANG YANG MENCAPAI BATAS MINIMUM</h1>
              </div>
              <hr>
              <div class="mt-4">
                <table class="table table-bordered" width="100%" cellspacing="0">
                  <thead class="bg-secondary text-white text-center">
                    <tr>
                      <th>No.</th>
                      <th>ID Barang</th>
                      <th>Nama Barang</th>
                      <th>Jenis Barang</th>
                      <th>Stok</th>
                      <th>Satuan</th>
                      <th>Lokasi Ruangan</th>
                      <th>Lokasi Rak</th>
                    </tr>
                  </thead>
                  <tbody class="text-dark">';
    // sql statement untuk menampilkan data dari tabel "tbl_barang", tabel "tbl_jenis", dan tabel "tbl_satuan" berdasarkan "stok"
    $query = mysqli_query($mysqli, "SELECT a.id_barang, a.nama_barang, a.jenis, a.stok_minimum, a.stok, a.satuan, a.lokasi_ruangan, a.lokasi_rak, b.nama_jenis, c.nama_satuan, d.lokasi_ruangan, e.lokasi_rak
										                FROM tbl_barang as a INNER JOIN tbl_jenis as b INNER JOIN tbl_satuan as c INNER JOIN tbl_lokasi as d INNER JOIN tbl_lokasi_rak as e ON a.jenis=b.id_jenis AND a.satuan=c.id_satuan  AND a.lokasi_ruangan=d.id_lokasi AND a.lokasi_rak=e.id_lokasi
										                WHERE a.stok<=a.stok_minimum ORDER BY a.id_barang ASC")
                                    or die('Ada kesalahan pada query tampil data : ' . mysqli_error($mysqli));
    // ambil data hasil query
    while ($data = mysqli_fetch_assoc($query)) {
      // tampilkan data
      $html .= '		<tr>
                      <td width="50" class="text-center">' . $no++ . '</td>
                      <td width="80" class="text-center">' . $data['id_barang'] . '</td>
                      <td width="200">' . $data['nama_barang'] . '</td>
                      <td width="140">' . $data['nama_jenis'] . '</td>
                      <td width="70" class="text-right">' . $data['stok'] . '</td>
                      <td width="80">' . $data['nama_satuan'] . '</td>
                      <td width="80">' . $data['lokasi_ruangan'] . '</td>
                      <td width="80">' . $data['lokasi_rak'] . '</td>
                    </tr>';
    }
    $html .= '		</tbody>
                </table>
              </div>
              <div class="footer">
        <p>............, <span class="date">'. tanggal_indo(date('Y-m-d')) .'</span></p>
    </div>
            </body>
            </html>';

    // load html
    $dompdf->loadHtml($html);
    // mengatur ukuran dan orientasi kertas
    $dompdf->setPaper('A4', 'landscape');
    // mengubah dari HTML menjadi PDF
    $dompdf->render();
    // menampilkan file PDF yang dihasilkan ke browser dan berikan nama file "Laporan Stok Barang Minimum.pdf"
    $dompdf->stream('Laporan Stok Barang Minimum.pdf', array('Attachment' => 0));
  }
}
