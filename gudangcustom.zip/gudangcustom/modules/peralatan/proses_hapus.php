<?php
session_start();      // mengaktifkan session

// pengecekan session login user 
// jika user belum login
if (empty($_SESSION['username']) && empty($_SESSION['password'])) {
  // alihkan ke halaman login dan tampilkan pesan peringatan login
  header('location: ../../login.php?pesan=2');
}
// jika user sudah login, maka jalankan perintah untuk delete
else {
  // panggil file "database.php" untuk koneksi ke database
  require_once "../../config/database.php";

  // mengecek data GET "id_peralatan"
  if (isset($_GET['id'])) {
    // ambil data GET dari tombol hapus
    $id_peralatan = mysqli_real_escape_string($mysqli, $_GET['id']);
      $query = mysqli_query($mysqli, "SELECT foto FROM tbl_peralatan WHERE id_peralatan='$id_peralatan'")
                                      or die('Ada kesalahan pada query tampil data : ' . mysqli_error($mysqli));
      // ambil data hasil query
      $data = mysqli_fetch_assoc($query);
      // tampilkan data
      $foto = $data['foto'];

      // jika data "foto" tidak kosong
      if (!empty($foto)) {
        // hapus file foto dari folder images
        $hapus_file = unlink("../../images/$foto");
      }

      // sql statement untuk delete data dari tabel "tbl_peralatan" berdasarkan "id_peralatan"
      $delete = mysqli_query($mysqli, "DELETE FROM tbl_peralatan WHERE id_peralatan='$id_peralatan'")
                                       or die('Ada kesalahan pada query delete : ' . mysqli_error($mysqli));
      // cek query
      // jika proses delete berhasil
      if ($delete) {
        // alihkan ke halaman peralatan dan tampilkan pesan berhasil hapus data
        header('location: ../../main.php?module=peralatan&pesan=3');
      }
    }
  }
