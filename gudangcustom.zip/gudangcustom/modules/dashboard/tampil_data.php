<?php
// mencegah direct access file PHP agar file PHP tidak bisa diakses secara langsung dari browser dan hanya dapat dijalankan ketika di include oleh file lain
// jika file diakses secara langsung
if (basename($_SERVER['PHP_SELF']) === basename(__FILE__)) {
  // alihkan ke halaman error 404
  header('location: 404.html');
}
// jika file di include oleh file lain, tampilkan isi file
else {
  // menampilkan pesan selamat datang
  // jika pesan tersedia
  if (isset($_GET['pesan'])) {
    // jika pesan = 1
    if ($_GET['pesan'] == 1) {
      // tampilkan pesan selamat datang
      echo '<div class="alert alert-notify alert-secondary alert-dismissible fade show" role="alert">
              <span data-notify="icon" class="fas fa-user-alt"></span> 
              <span data-notify="title" class="text-secondary">Hi! ' . $_SESSION['nama_user'] . '</span> 
              <span data-notify="message">Selamat Datang di Aplikasi Gudang Material.</span>
              <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>';
    }
  }
?>
  <div class="panel-header" style="background: linear-gradient(to bottom, #800000, #b22222);">
    <div class="page-inner py-5">
      <div class="d-flex align-items-left align-items-md-top flex-column flex-md-row">
        <div class="page-header text-white">
          <!-- judul halaman -->
          <h4 class="page-title text-white"><i class="fas fa-home mr-2"></i> Dashboard</h4>
        </div>
      </div>
    </div>
  </div>
  <div class="page-inner mt--5">
    <div class="row row-card-no-pd mt--2">
      <!-- menampilkan informasi jumlah data barang -->
      <div class="col-sm-12 col-md-4">
        <div class="card card-stats card-round">
          <div class="card-body ">
            <div class="row">
              <div class="col-5">
                <div class="icon-big2 text-center">
                  <i class="fas fa-users text-secondary"></i> <!-- Ikon Pekerja -->
                </div>
              </div>
              <div class="col-7 col-stats">
                <div class="numbers">
                  <p class="card-category">Data Pekerja</p>
                  <?php
                  $query = mysqli_query($mysqli, "SELECT * FROM tbl_pekerja")
                    or die('Ada kesalahan pada query jumlah data pekerja : ' . mysqli_error($mysqli));
                  $jumlah_pekerja = mysqli_num_rows($query);
                  ?>
                  <h4 class="card-title"><?php echo number_format($jumlah_pekerja, 0, '', '.'); ?></h4>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Data Peralatan -->
      <div class="col-sm-12 col-md-4">
        <div class="card card-stats card-round">
          <div class="card-body ">
            <div class="row">
              <div class="col-5">
                <div class="icon-big2 text-center">
                  <i class="fas fa-tools text-success"></i> <!-- Ikon Peralatan -->
                </div>
              </div>
              <div class="col-7 col-stats">
                <div class="numbers">
                  <p class="card-category">Data Peralatan</p>
                  <?php
                  $query = mysqli_query($mysqli, "SELECT * FROM tbl_peralatan")
                    or die('Ada kesalahan pada query jumlah data peralatan : ' . mysqli_error($mysqli));
                  $jumlah_peralatan = mysqli_num_rows($query);
                  ?>
                  <h4 class="card-title"><?php echo number_format($jumlah_peralatan, 0, '', '.'); ?></h4>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Data Penggunaan Peralatan -->
      <div class="col-sm-12 col-md-4">
        <div class="card card-stats card-round">
          <div class="card-body">
            <div class="row">
              <div class="col-5">
                <div class="icon-big2 text-center">
                  <i class="fas fa-clipboard-list text-warning"></i> <!-- Ikon Penggunaan -->
                </div>
              </div>
              <div class="col-7 col-stats">
                <div class="numbers">
                  <p class="card-category">Data Penggunaan Peralatan</p>
                  <?php
                  $query = mysqli_query($mysqli, "SELECT * FROM tbl_penggunaan")
                    or die('Ada kesalahan pada query jumlah data penggunaan : ' . mysqli_error($mysqli));
                  $jumlah_penggunaan = mysqli_num_rows($query);
                  ?>
                  <h4 class="card-title"><?php echo number_format($jumlah_penggunaan, 0, '', '.'); ?></h4>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      </div>
      </div>

    <?php } ?>