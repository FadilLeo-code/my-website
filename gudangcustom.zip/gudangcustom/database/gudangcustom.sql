-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 23, 2025 at 01:41 PM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 7.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gudangcustom`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_pekerja`
--

CREATE TABLE `tbl_pekerja` (
  `id_pekerja` int(11) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `no_wa` varchar(15) NOT NULL,
  `foto` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_pekerja`
--

INSERT INTO `tbl_pekerja` (`id_pekerja`, `nama`, `no_wa`, `foto`) VALUES
(3, 'tutiii', '9585747373', '333fb35f8d7ba439544162b3515b994c5218c8a8.png');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_penggunaan`
--

CREATE TABLE `tbl_penggunaan` (
  `id_penggunaan` int(11) NOT NULL,
  `pekerja_id` int(11) DEFAULT NULL,
  `peralatan_id` int(11) DEFAULT NULL,
  `tanggal_gunakan` varchar(255) NOT NULL,
  `tanggal_kembali` varchar(255) DEFAULT NULL,
  `status_barang` enum('Baik','Tidak Baik') DEFAULT 'Baik',
  `keterangan` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

--
-- Dumping data for table `tbl_penggunaan`
--

INSERT INTO `tbl_penggunaan` (`id_penggunaan`, `pekerja_id`, `peralatan_id`, `tanggal_gunakan`, `tanggal_kembali`, `status_barang`, `keterangan`) VALUES
(2, 3, 2, '23-02-2025', '27-02-2025', 'Baik', 'mantap');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_peralatan`
--

CREATE TABLE `tbl_peralatan` (
  `id_peralatan` int(11) NOT NULL,
  `tanggal` varchar(255) NOT NULL,
  `nama_peralatan` varchar(255) NOT NULL,
  `terima_dari` varchar(255) NOT NULL,
  `foto` varchar(255) DEFAULT NULL,
  `keterangan` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_peralatan`
--

INSERT INTO `tbl_peralatan` (`id_peralatan`, `tanggal`, `nama_peralatan`, `terima_dari`, `foto`, `keterangan`) VALUES
(2, '23-02-2025', 'tang', 'toko leovinia cide', '73840adb60630d812ce9c8cf470a55568c384dd7.png', 'mantaaap');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `id_user` int(11) NOT NULL,
  `nama_user` varchar(30) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(255) NOT NULL,
  `hak_akses` enum('Administrator','Admin Gudang','Kepala Gudang','Operator') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`id_user`, `nama_user`, `username`, `password`, `hak_akses`) VALUES
(1, 'Admin', 'administrator', '$2y$12$Yi/I5f1jPoQNQnh6lWoVfuz.RtZ3OHcKN6PU.I62P0fYK1tJ7xMRi', 'Administrator'),
(2, 'Admin Gudang', 'admin gudang', '$2y$12$BeRYh13zfPXej97VgcfeNucYJGTElha5sRyIUQm1278D2u2Aqf6DS', 'Admin Gudang'),
(3, 'Kepala Gudang', 'kepala gudang', '$2y$12$odXcPs.RLJJH6Ghv3s42c.5zg5qAOz/S3Adr0lXGNcVSJ6f1hHS6G', 'Kepala Gudang'),
(4, 'Bolas Rozier', 'Bolas', '$2y$12$o6vvM0CiakjacoUv4egdtuSfMqzdivaM3kX2YQ3JUUDcvFnjnBnq6', 'Admin Gudang'),
(6, 'fadil', 'operator', '$2y$12$tlLvKK42SnDAqxmziMWGJOfqAyKl8fG1ndZzVQ7iFxe.NMyfKtAtm', 'Operator');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_pekerja`
--
ALTER TABLE `tbl_pekerja`
  ADD PRIMARY KEY (`id_pekerja`);

--
-- Indexes for table `tbl_penggunaan`
--
ALTER TABLE `tbl_penggunaan`
  ADD PRIMARY KEY (`id_penggunaan`);

--
-- Indexes for table `tbl_peralatan`
--
ALTER TABLE `tbl_peralatan`
  ADD PRIMARY KEY (`id_peralatan`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_pekerja`
--
ALTER TABLE `tbl_pekerja`
  MODIFY `id_pekerja` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `tbl_penggunaan`
--
ALTER TABLE `tbl_penggunaan`
  MODIFY `id_penggunaan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `tbl_peralatan`
--
ALTER TABLE `tbl_peralatan`
  MODIFY `id_peralatan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
